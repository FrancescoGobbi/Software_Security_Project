if Riccardo >= Francesco:
    PromessiSposi(Riccardo, Francesco)
else:
    PromessiSposi(Francesco, Riccardo)