Riccardo = 5
Francesco = 3

i = 0
while i<Riccardo:
    Francesco+=1

Riccardo+=5