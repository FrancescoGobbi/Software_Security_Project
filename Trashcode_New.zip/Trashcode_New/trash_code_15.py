Università(Sicurezza)

if Univr>=10:
    Sicurezza+=1
    Embedded+=1
    Visual+=1  