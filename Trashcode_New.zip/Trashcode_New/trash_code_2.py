if Balcone == 1:
    Romeo = 20
else:
    Romeo = 0