if Balcone == 1:
    Giulietta = 0
else:
    Giulietta = 20