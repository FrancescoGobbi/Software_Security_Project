Romeo = 10
Giulietta = 20
Don_Abbondio = 0

while Romeo <= Giulietta:
    Romeo+=1
    Don_Abbondio+=1
