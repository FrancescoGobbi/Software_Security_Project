Balcone = 0

if Romeo < Giulietta:
    Balcone = 0
else:
    Balcone = 1
