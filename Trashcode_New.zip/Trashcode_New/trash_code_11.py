if Sicurezza > Visual:
    Univr+=3
else:
    Unvir-=5

if Univr >= 10:
    Sicurezza+=1
    Visual+=3
    Embedded+=3