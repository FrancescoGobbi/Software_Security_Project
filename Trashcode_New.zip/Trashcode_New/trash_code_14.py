def Università(Indirizzo):
    if Indirizzo>=10:
        Univr+=10
    else:
        Univr+=2
    