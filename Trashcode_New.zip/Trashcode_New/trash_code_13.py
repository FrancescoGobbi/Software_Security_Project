if Romeo > Giulietta:
    PromessiSposi(Guleitta, Romeo)
else:
    William(Romeo, Giulietta)