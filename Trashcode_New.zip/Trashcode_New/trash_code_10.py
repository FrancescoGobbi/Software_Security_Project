if Sicurezza > Embedded:
    Univr+=3
else: 
    Univr-=10