UniVr = 10
Didattica = 5
Progetto = 0

if UniVr >= Didattica:
    if Riccardo > Francesco:
        if Romeo > Giulietta:
            Progetto = 1
        
        else:
            Progetto = 2
    else:
        Progetto = 3
else:
    Progetto = 4