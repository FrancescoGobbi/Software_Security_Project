if DonAbbondio >= 10:
    Romeo-=2
    Giulietta-=1

else:
    Romeo+=Giulietta