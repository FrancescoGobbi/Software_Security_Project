if Don_Abbondio > 10:
    Romeo = 0
else:
    Romeo = 20