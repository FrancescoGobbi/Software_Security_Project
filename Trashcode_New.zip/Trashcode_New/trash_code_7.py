def William(Romeo,Giulietta):
    if Romeo > Giulietta:
        Giulietta+=5

    else:
        Romeo+=5
