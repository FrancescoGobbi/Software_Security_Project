#variable

Sicurezza = 10
Visual = 10
Embedded = 10

UniVr = 10
Didattica = 10
Progetto = 10

Riccardo = 10
Francesco = 10

Giulietta = 10
Romeo = 10
DonAbbondio = 10