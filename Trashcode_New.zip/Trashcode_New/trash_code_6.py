def PromessiSposi(x, y):
    while x>y:
        y+=1

    if y>x:
        x+=5
        y+=5
    